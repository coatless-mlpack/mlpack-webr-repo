

// This file support the legacy location and includes from the new location

#include "RcppArmadillo/interface/RcppArmadilloSugar.h"
