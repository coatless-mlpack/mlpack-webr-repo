
// This file support the legacy location and includes from the new location

#include "RcppArmadillo/rng/Alt_R_RNG.h"
